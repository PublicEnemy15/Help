package Cine;
public class Mantenimiento1 extends javax.swing.JInternalFrame {
    private double precioBaseSeleccionado;
    public Mantenimiento1() {
        initComponents();
        
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblPelicula = new javax.swing.JLabel();
        lblPrecioUSD = new javax.swing.JLabel();
        lblFormato = new javax.swing.JLabel();
        lblPrecioS = new javax.swing.JLabel();
        lblGenero = new javax.swing.JLabel();
        txtGenero = new javax.swing.JTextField();
        txtPrecioUSD = new javax.swing.JTextField();
        txtPrecioS = new javax.swing.JTextField();
        btnCerrar = new javax.swing.JButton();
        cmbFuncion = new javax.swing.JComboBox<>();
        cmbPelicula1 = new javax.swing.JComboBox<>();
        lblDuracion = new javax.swing.JLabel();
        txtDuracion = new javax.swing.JTextField();
        lblCE = new javax.swing.JLabel();
        txtCE = new javax.swing.JTextField();
        btnLimpiar = new javax.swing.JButton();
        lblGenero1 = new javax.swing.JLabel();
        cmbFormato1 = new javax.swing.JComboBox<>();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Consultar medicamento");
        setName(""); // NOI18N
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblPelicula.setText("Pelicula");
        getContentPane().add(lblPelicula, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        lblPrecioUSD.setText("Precio (USD $)");
        getContentPane().add(lblPrecioUSD, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, -1, -1));

        lblFormato.setText("Formato");
        getContentPane().add(lblFormato, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, 20));

        lblPrecioS.setText("Precio (S/.)");
        getContentPane().add(lblPrecioS, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, -1, -1));

        lblGenero.setText("Genero");
        getContentPane().add(lblGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, -1));

        txtGenero.setEnabled(false);
        txtGenero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGeneroActionPerformed(evt);
            }
        });
        getContentPane().add(txtGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 170, -1));

        txtPrecioUSD.setEnabled(false);
        txtPrecioUSD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioUSDActionPerformed(evt);
            }
        });
        getContentPane().add(txtPrecioUSD, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 170, -1));

        txtPrecioS.setEnabled(false);
        txtPrecioS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioSActionPerformed(evt);
            }
        });
        getContentPane().add(txtPrecioS, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, 170, -1));

        btnCerrar.setText("Salir");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 350, -1, -1));

        cmbFuncion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar ", "2D", "3D", "DBOX", "XD", "DOB" }));
        cmbFuncion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFuncionActionPerformed(evt);
            }
        });
        getContentPane().add(cmbFuncion, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 110, 170, -1));

        cmbPelicula1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "Atentado en el Aire", "El Exorcista: Creyentes", "Sonido De Libertad", "El Caso Monroy", "Saw X: El Juego del Miedo" }));
        cmbPelicula1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbPelicula1ActionPerformed(evt);
            }
        });
        getContentPane().add(cmbPelicula1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, 170, -1));

        lblDuracion.setText("Duracion");
        getContentPane().add(lblDuracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));

        txtDuracion.setEnabled(false);
        txtDuracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDuracionActionPerformed(evt);
            }
        });
        getContentPane().add(txtDuracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, 170, -1));

        lblCE.setText("Clasificación por edades");
        getContentPane().add(lblCE, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, -1, -1));

        txtCE.setEnabled(false);
        txtCE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCEActionPerformed(evt);
            }
        });
        getContentPane().add(txtCE, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 170, -1));

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 350, -1, -1));

        lblGenero1.setText("Funcion");
        getContentPane().add(lblGenero1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, -1, -1));

        cmbFormato1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar ", "2D", "3D", "DBOX", "XD", "DOB" }));
        cmbFormato1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFormato1ActionPerformed(evt);
            }
        });
        getContentPane().add(cmbFormato1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 170, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
       dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void cmbFuncionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFuncionActionPerformed
  
    }//GEN-LAST:event_cmbFuncionActionPerformed

    private void cmbPelicula1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPelicula1ActionPerformed
      // Actualiza el precio base al seleccionar una película
    actualizarPrecioBase();
    
    // Actualiza el genero, duracion, y clasificacion utilizando la lógica del cine
    LogicaCine.actualizarGeneroDuracionClasificacion(
            cmbPelicula1.getSelectedItem().toString(),
            txtGenero,
            txtDuracion,
            txtCE
    );
    
    // Muestra el precio base en el campo txtPrecioUSD
    txtPrecioUSD.setText(String.valueOf(precioBaseSeleccionado));

    // Convierte y muestra el precio en soles en el campo txtPrecioS
    double precioEnSoles = LogicaCine.convertirDolaresASoles(precioBaseSeleccionado);
    txtPrecioS.setText(String.valueOf(precioEnSoles));
    }//GEN-LAST:event_cmbPelicula1ActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
cmbPelicula1.setSelectedIndex(0); // Establece el índice seleccionado en "Seleccionar"
    txtGenero.setText("");
    txtDuracion.setText("");
    txtClasificacion.setText("");
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void txtGeneroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGeneroActionPerformed

    }//GEN-LAST:event_txtGeneroActionPerformed

    private void txtDuracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDuracionActionPerformed

    }//GEN-LAST:event_txtDuracionActionPerformed

    private void txtCEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCEActionPerformed

    }//GEN-LAST:event_txtCEActionPerformed

    private void txtPrecioUSDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioUSDActionPerformed
  
    }//GEN-LAST:event_txtPrecioUSDActionPerformed

    private void txtPrecioSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioSActionPerformed

    }//GEN-LAST:event_txtPrecioSActionPerformed

    private void cmbFormato1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFormato1ActionPerformed
      // Actualiza el precio base y formato al seleccionar un formato
    actualizarPrecioBaseYFormato();

    // Muestra el precio base en el campo txtPrecioUSD
    txtPrecioUSD.setText(String.valueOf(precioBaseSeleccionado));

    // Convierte y muestra el precio en soles en el campo txtPrecioS
    double precioEnSoles = LogicaCine.convertirDolaresASoles(precioBaseSeleccionado);
    txtPrecioS.setText(String.valueOf(precioEnSoles));
    }//GEN-LAST:event_cmbFormato1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<String> cmbFormato1;
    private javax.swing.JComboBox<String> cmbFuncion;
    private javax.swing.JComboBox<String> cmbPelicula1;
    private javax.swing.JLabel lblCE;
    private javax.swing.JLabel lblDuracion;
    private javax.swing.JLabel lblFormato;
    private javax.swing.JLabel lblGenero;
    private javax.swing.JLabel lblGenero1;
    private javax.swing.JLabel lblPelicula;
    private javax.swing.JLabel lblPrecioS;
    private javax.swing.JLabel lblPrecioUSD;
    private javax.swing.JTextField txtCE;
    private javax.swing.JTextField txtDuracion;
    private javax.swing.JTextField txtGenero;
    private javax.swing.JTextField txtPrecioS;
    private javax.swing.JTextField txtPrecioUSD;
    // End of variables declaration//GEN-END:variables

    private static class txtClasificacion {

        private static void setText(String string) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public txtClasificacion() {
        }
    }
    private void actualizarPrecioBase() {
        int indexPelicula = LogicaCine.buscarPelicula(cmbPelicula1.getSelectedItem().toString());
        if (indexPelicula >= 0) {
            precioBaseSeleccionado = LogicaCine.PRECIOS_USD[indexPelicula];
        } else {
            precioBaseSeleccionado = 0.0; // Precio base predeterminado si no se encuentra la película
        }
    }
    private void actualizarPrecioBaseYFormato() {
    int indexPelicula = LogicaCine.buscarPelicula(cmbPelicula1.getSelectedItem().toString());
    int indexFormato = cmbFormato1.getSelectedIndex();

    if (indexPelicula >= 0 && indexFormato >= 0) {
        // Actualiza el precio base y formato
        precioBaseSeleccionado = LogicaCine.PRECIOS_USD[indexPelicula] * LogicaCine.PRECIOS_POR_FORMATO[indexFormato];
    } else {
        precioBaseSeleccionado = 0.0; // Precio base predeterminado si no se encuentra la película o el formato
    }
}
}
