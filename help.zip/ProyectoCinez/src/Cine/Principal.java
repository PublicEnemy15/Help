package Cine;
public class Principal extends javax.swing.JFrame {
    public Principal() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dpSistema = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnArchivo = new javax.swing.JMenu();
        mnSalir = new javax.swing.JMenuItem();
        mnMantenimiento = new javax.swing.JMenu();
        mnConsultar = new javax.swing.JMenuItem();
        mnConfigurar = new javax.swing.JMenuItem();
        mnLista = new javax.swing.JMenuItem();
        mnVentas = new javax.swing.JMenu();
        mnVender = new javax.swing.JMenuItem();
        mnGenerar = new javax.swing.JMenuItem();
        mnConfiguracion = new javax.swing.JMenu();
        mnConfigurarDescuento = new javax.swing.JMenuItem();
        mnTipodeCambio = new javax.swing.JMenuItem();
        mnOptima = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cine");

        dpSistema.setName(""); // NOI18N

        javax.swing.GroupLayout dpSistemaLayout = new javax.swing.GroupLayout(dpSistema);
        dpSistema.setLayout(dpSistemaLayout);
        dpSistemaLayout.setHorizontalGroup(
            dpSistemaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1037, Short.MAX_VALUE)
        );
        dpSistemaLayout.setVerticalGroup(
            dpSistemaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 458, Short.MAX_VALUE)
        );

        mnArchivo.setText("Archivo");

        mnSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mnSalir.setText("Salir");
        mnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnSalirActionPerformed(evt);
            }
        });
        mnArchivo.add(mnSalir);

        jMenuBar1.add(mnArchivo);

        mnMantenimiento.setText("Mantenimiento");

        mnConsultar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mnConsultar.setText("Consultar Peliculas");
        mnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnConsultarActionPerformed(evt);
            }
        });
        mnMantenimiento.add(mnConsultar);

        mnConfigurar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mnConfigurar.setText("Configurar precios");
        mnConfigurar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnConfigurarActionPerformed(evt);
            }
        });
        mnMantenimiento.add(mnConfigurar);

        mnLista.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mnLista.setText("Listas de Peliculas");
        mnLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnListaActionPerformed(evt);
            }
        });
        mnMantenimiento.add(mnLista);

        jMenuBar1.add(mnMantenimiento);

        mnVentas.setText("Ventas");

        mnVender.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mnVender.setText("Vender entrada");
        mnVender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnVenderActionPerformed(evt);
            }
        });
        mnVentas.add(mnVender);

        mnGenerar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_G, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mnGenerar.setText("Generar reporte");
        mnGenerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnGenerarActionPerformed(evt);
            }
        });
        mnVentas.add(mnGenerar);

        jMenuBar1.add(mnVentas);

        mnConfiguracion.setText("Configuracion");

        mnConfigurarDescuento.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mnConfigurarDescuento.setText("Configura descuentos");
        mnConfigurarDescuento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnConfigurarDescuentoActionPerformed(evt);
            }
        });
        mnConfiguracion.add(mnConfigurarDescuento);

        mnTipodeCambio.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mnTipodeCambio.setText("Configurar tipo de cambio");
        mnTipodeCambio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnTipodeCambioActionPerformed(evt);
            }
        });
        mnConfiguracion.add(mnTipodeCambio);

        mnOptima.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mnOptima.setText("Cantidad optima de ventas");
        mnOptima.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnOptimaActionPerformed(evt);
            }
        });
        mnConfiguracion.add(mnOptima);

        jMenuBar1.add(mnConfiguracion);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dpSistema)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dpSistema)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnSalirActionPerformed
       System.exit(0);
    }//GEN-LAST:event_mnSalirActionPerformed

    private void mnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnConsultarActionPerformed
       Mantenimiento1 frmMantenimiento1=new Mantenimiento1 ();
       dpSistema.add(frmMantenimiento1);
       frmMantenimiento1.show();
    }//GEN-LAST:event_mnConsultarActionPerformed

    private void mnListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnListaActionPerformed
        Mantenimiento3  frmMantenimiento3 =new Mantenimiento3  ();
       dpSistema.add(frmMantenimiento3 );
       frmMantenimiento3 .show();
    }//GEN-LAST:event_mnListaActionPerformed

    private void mnConfigurarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnConfigurarActionPerformed
       Mantenimiento2 frmMantenimiento2=new Mantenimiento2();
       dpSistema.add(frmMantenimiento2);
       frmMantenimiento2.show();
    }//GEN-LAST:event_mnConfigurarActionPerformed

    private void mnVenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnVenderActionPerformed
       Ventas1 frmventas1=new  Ventas1();
       dpSistema.add(frmventas1);
       frmventas1.show();
    }//GEN-LAST:event_mnVenderActionPerformed

    private void mnGenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnGenerarActionPerformed
       Ventas2 frmventas2=new  Ventas2();
       dpSistema.add(frmventas2);
       frmventas2.show();
    }//GEN-LAST:event_mnGenerarActionPerformed

    private void mnConfigurarDescuentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnConfigurarDescuentoActionPerformed
        Configuracion1 frmConfiguracion1=new  Configuracion1();
       dpSistema.add(frmConfiguracion1);
       frmConfiguracion1.show();
    }//GEN-LAST:event_mnConfigurarDescuentoActionPerformed

    private void mnTipodeCambioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnTipodeCambioActionPerformed
       Configuracion2  frmConfiguracion2 =new  Configuracion2 ();
       dpSistema.add(frmConfiguracion2);
       frmConfiguracion2 .show();
    }//GEN-LAST:event_mnTipodeCambioActionPerformed

    private void mnOptimaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnOptimaActionPerformed
        Configuracion3  frmConfiguracion3 =new  Configuracion3 ();
       dpSistema.add(frmConfiguracion3 );
       frmConfiguracion3.show();
    }//GEN-LAST:event_mnOptimaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane dpSistema;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu mnArchivo;
    private javax.swing.JMenu mnConfiguracion;
    private javax.swing.JMenuItem mnConfigurar;
    private javax.swing.JMenuItem mnConfigurarDescuento;
    private javax.swing.JMenuItem mnConsultar;
    private javax.swing.JMenuItem mnGenerar;
    private javax.swing.JMenuItem mnLista;
    private javax.swing.JMenu mnMantenimiento;
    private javax.swing.JMenuItem mnOptima;
    private javax.swing.JMenuItem mnSalir;
    private javax.swing.JMenuItem mnTipodeCambio;
    private javax.swing.JMenuItem mnVender;
    private javax.swing.JMenu mnVentas;
    // End of variables declaration//GEN-END:variables
}
