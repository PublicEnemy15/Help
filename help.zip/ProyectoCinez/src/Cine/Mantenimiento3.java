package Cine;
public class Mantenimiento3 extends javax.swing.JInternalFrame {
    public Mantenimiento3() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnSalir = new javax.swing.JButton();
        btnListar = new javax.swing.JButton();
        scpLista = new javax.swing.JScrollPane();
        txtL = new javax.swing.JTextArea();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("LISTAR PELICULAS");

        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnListar.setText("Listar");
        btnListar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarActionPerformed(evt);
            }
        });

        txtL.setColumns(20);
        txtL.setLineWrap(true);
        txtL.setRows(5);
        txtL.setWrapStyleWord(true);
        scpLista.setViewportView(txtL);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(btnSalir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 84, Short.MAX_VALUE)
                .addComponent(btnListar)
                .addGap(87, 87, 87))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scpLista)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scpLista, javax.swing.GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalir)
                    .addComponent(btnListar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarActionPerformed
        listarPeliculas();
    }//GEN-LAST:event_btnListarActionPerformed
    
    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
       dispose();
    }//GEN-LAST:event_btnSalirActionPerformed
    private void listarPeliculas() {
        // Limpia el área de texto antes de listar
        txtL.setText("");

        // Recorre las películas y muestra la información
        for (int i = 1; i < LogicaCine.PELICULA.length; i++) {
            String pelicula = LogicaCine.PELICULA[i];
            double precioUSD = LogicaCine.PRECIOS_USD[i];

            // Puedes agregar más información según sea necesario

            // Construye una pequeña sinopsis (puedes personalizar esto)
            String sinopsis = obtenerSinopsis(pelicula);

            // Muestra la información en el área de texto
            txtL.append("Película: " + pelicula + "\n");
            txtL.append("Formatos disponibles: " + obtenerFormatosDisponibles() + "\n");
            txtL.append("Precio (USD): " + precioUSD + "\n");

            // Convierte y muestra el precio en soles
            double precioEnSoles = LogicaCine.convertirDolaresASoles(precioUSD);
            txtL.append("Precio (Soles): " + precioEnSoles + "\n");

            txtL.append(sinopsis + "\n");
            txtL.append("\n--------------------------\n");
        }
    }

    private String obtenerSinopsis(String pelicula) {
        // Implementa la lógica para obtener la sinopsis de la película
        // Por ahora, retorna una sinopsis genérica
        return "Sinopsis de " + pelicula + ": Una emocionante historia cinematográfica.";
    }

    private String obtenerFormatosDisponibles() {
        // Construye una cadena con todos los formatos disponibles
        StringBuilder formatos = new StringBuilder();
        for (String formato : LogicaCine.FORMATO) {
            if (!formato.equals("Seleccionar")) {
                formatos.append(formato).append(", ");
            }
        }

        // Elimina la coma y el espacio al final de la cadena
        if (formatos.length() > 2) {
            formatos.delete(formatos.length() - 2, formatos.length());
        }

        return formatos.toString();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnListar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JScrollPane scpLista;
    private javax.swing.JTextArea txtL;
    // End of variables declaration//GEN-END:variables
}
