
package Cine;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Ventas1 extends javax.swing.JInternalFrame {

    public Ventas1() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnVender = new javax.swing.JButton();
        scpVenta = new javax.swing.JScrollPane();
        txtV = new javax.swing.JTextArea();
        cmbPelicula = new javax.swing.JComboBox<>();
        lblPelicula = new javax.swing.JLabel();
        lblFormato = new javax.swing.JLabel();
        lblCantidad1 = new javax.swing.JLabel();
        txtCantidad1 = new javax.swing.JTextField();
        btnSalir1 = new javax.swing.JButton();
        cmbFormato = new javax.swing.JComboBox<>();
        cmbFuncion = new javax.swing.JComboBox<>();
        lblFormato1 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Vender medicamento");
        setToolTipText("");

        btnVender.setText("Vender");
        btnVender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVenderActionPerformed(evt);
            }
        });

        txtV.setColumns(20);
        txtV.setRows(5);
        scpVenta.setViewportView(txtV);

        cmbPelicula.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "Atentado en el Aire", "El Exorcista: Creyentes", "Sonido De Libertad", "El Caso Monroy", "Saw X: El Juego del Miedo" }));
        cmbPelicula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbPeliculaActionPerformed(evt);
            }
        });

        lblPelicula.setText("Pelicula:");

        lblFormato.setText("Formato");

        lblCantidad1.setText("Cantidad:");

        txtCantidad1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidad1ActionPerformed(evt);
            }
        });

        btnSalir1.setText("Salir");
        btnSalir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalir1ActionPerformed(evt);
            }
        });

        cmbFormato.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar ", "2D", "3D", "DBOX", "XD", "DOB" }));
        cmbFormato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFormatoActionPerformed(evt);
            }
        });

        cmbFuncion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar ", "2D", "3D", "DBOX", "XD", "DOB" }));
        cmbFuncion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFuncionActionPerformed(evt);
            }
        });

        lblFormato1.setText("Funcion");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(scpVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblFormato1)
                        .addGap(29, 29, 29)
                        .addComponent(cmbFuncion, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblCantidad1)
                                .addGap(23, 23, 23)
                                .addComponent(txtCantidad1))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblPelicula)
                                    .addComponent(lblFormato))
                                .addGap(29, 29, 29)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmbPelicula, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbFormato, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnVender)
                            .addComponent(btnSalir1))
                        .addGap(35, 35, 35))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPelicula)
                    .addComponent(btnVender)
                    .addComponent(cmbPelicula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFormato)
                    .addComponent(cmbFormato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFormato1)
                    .addComponent(cmbFuncion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCantidad1)
                    .addComponent(txtCantidad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalir1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(scpVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbPeliculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPeliculaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbPeliculaActionPerformed

    private void btnVenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVenderActionPerformed
try {
        // Obtener la cantidad ingresada
        int cantidad = Integer.parseInt(txtCantidad1.getText());

        String pelicula = cmbPelicula.getSelectedItem().toString();
        String formato = cmbFormato.getSelectedItem().toString();
        String funcion = cmbFuncion.getSelectedItem().toString();

        // Actualizar la cantidad de entradas vendidas en LogicaCine
        int indexPelicula = LogicaCine.buscarPelicula(pelicula);
        if (indexPelicula >= 0) {
            LogicaCine.entradasVendidasPorPelicula[indexPelicula] += cantidad;
        }

        // Obtener el precio base según la película y formato seleccionados
        
        BigDecimal precioBase = LogicaCine.obtenerPrecioBase(pelicula, formato);

        BigDecimal precioFormato = LogicaCine.obtenerPrecioFormato(formato);

        // Calcular el importe sin IGV
        BigDecimal importeSinIGV = precioBase.add(precioFormato);

        // Calcular el IGV (18%)
        BigDecimal igv = importeSinIGV.multiply(BigDecimal.valueOf(0.18)).setScale(2, RoundingMode.HALF_UP);

        // Calcular el importe total con IGV
         BigDecimal importeTotal = importeSinIGV.add(igv);
         LogicaCine.registrarVenta(pelicula, importeTotal.doubleValue());

        // Imprimir la boleta en el área de texto
        txtV.setText("Boleta de Venta\n");
        txtV.append("Pelicula: " + pelicula + "\n");
        txtV.append("Formato: " + formato + "\n");
        txtV.append("Función: " + funcion + "\n");
        txtV.append("Cantidad: " + cantidad + " entradas\n");
        txtV.append("Precio Base (USD): $" + precioBase + "\n");
        txtV.append("Precio Formato (USD): $" + precioFormato + "\n");
        txtV.append("Importe sin IGV (USD): $" + importeSinIGV + "\n");
        txtV.append("IGV (USD): $" + igv + "\n");
        txtV.append("Importe Total (USD): $" + importeTotal + "\n");

        // Convertir a soles usando el tipo de cambio
        double tipoCambio = 3.50; // Tipo de cambio USD a Soles
        BigDecimal importeSinIGVSoles = importeSinIGV.multiply(BigDecimal.valueOf(tipoCambio)).setScale(2, RoundingMode.HALF_UP);
        BigDecimal igvSoles = igv.multiply(BigDecimal.valueOf(tipoCambio)).setScale(2, RoundingMode.HALF_UP);
        BigDecimal importeTotalSoles = importeTotal.multiply(BigDecimal.valueOf(tipoCambio)).setScale(2, RoundingMode.HALF_UP);

        // Imprimir en soles
        txtV.append("\nImporte sin IGV (Soles): S/." + importeSinIGVSoles + "\n");
        txtV.append("IGV (Soles): S/." + igvSoles + "\n");
        txtV.append("Importe Total (Soles): S/." + importeTotalSoles);

    } catch (NumberFormatException e) {
        // Manejar la excepción si la cantidad no es un número válido
        txtV.setText("Error: Ingrese una cantidad válida.");
    }         
    }//GEN-LAST:event_btnVenderActionPerformed

    private void txtCantidad1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidad1ActionPerformed

    }//GEN-LAST:event_txtCantidad1ActionPerformed

    private void btnSalir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalir1ActionPerformed
 dispose();
    }//GEN-LAST:event_btnSalir1ActionPerformed

    private void cmbFormatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFormatoActionPerformed

    }//GEN-LAST:event_cmbFormatoActionPerformed

    private void cmbFuncionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFuncionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbFuncionActionPerformed

    private BigDecimal calcularPrecioTotal(BigDecimal precioBase, int cantidad) {
        // Lógica para calcular el precio total (aquí puedes considerar descuentos u otros factores)
        BigDecimal precioTotal = precioBase.multiply(BigDecimal.valueOf(cantidad));
        return precioTotal.setScale(2, RoundingMode.HALF_UP);
    }
    private void mostrarInformacionVenta(String pelicula, String formato, String funcion, int cantidad, BigDecimal precioTotal) {
        // Construir la boleta y mostrarla en el área de texto
        StringBuilder boleta = new StringBuilder();
        boleta.append("BOLETA DE VENTA\n\n");
        boleta.append("Película: ").append(pelicula).append("\n");
        boleta.append("Formato: ").append(formato).append("\n");
        boleta.append("Función: ").append(funcion).append("\n");
        boleta.append("Cantidad: ").append(cantidad).append("\n");
        boleta.append("Precio Total: $").append(precioTotal).append("\n");

        // Mostrar la boleta en el área de texto
        txtV.setText(boleta.toString());
    }    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalir1;
    private javax.swing.JButton btnVender;
    private javax.swing.JComboBox<String> cmbFormato;
    private javax.swing.JComboBox<String> cmbFuncion;
    private javax.swing.JComboBox<String> cmbPelicula;
    private javax.swing.JLabel lblCantidad1;
    private javax.swing.JLabel lblFormato;
    private javax.swing.JLabel lblFormato1;
    private javax.swing.JLabel lblPelicula;
    private javax.swing.JScrollPane scpVenta;
    private javax.swing.JTextField txtCantidad1;
    private javax.swing.JTextArea txtV;
    // End of variables declaration//GEN-END:variables
}