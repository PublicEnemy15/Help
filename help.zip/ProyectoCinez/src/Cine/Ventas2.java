package Cine;
public class Ventas2 extends javax.swing.JInternalFrame {
    public Ventas2() {
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblReporte = new javax.swing.JLabel();
        cmbReporte = new javax.swing.JComboBox<>();
        btbSalir = new javax.swing.JButton();
        scpReporte = new javax.swing.JScrollPane();
        txtR = new javax.swing.JTextArea();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Generar reporte");

        lblReporte.setText("Tipo de reporte");

        cmbReporte.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ventas por Pelicula", "Pelicula con ventas optimas ", "Pelicula con precios superiores al precio promedio", "Pelicula con precios inferiores al precio promedio" }));
        cmbReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbReporteActionPerformed(evt);
            }
        });

        btbSalir.setText("Salir");
        btbSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbSalirActionPerformed(evt);
            }
        });

        txtR.setColumns(20);
        txtR.setRows(5);
        scpReporte.setViewportView(txtR);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(lblReporte)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cmbReporte, 0, 367, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btbSalir)
                .addGap(15, 15, 15))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scpReporte)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblReporte)
                    .addComponent(cmbReporte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btbSalir))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scpReporte, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btbSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbSalirActionPerformed
       dispose();
    }//GEN-LAST:event_btbSalirActionPerformed

    private void cmbReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbReporteActionPerformed
String tipoReporte = cmbReporte.getSelectedItem().toString();

    if (tipoReporte.equals("Ventas por Pelicula")) {
        // ... (código existente)
    } else if (tipoReporte.equals("Pelicula con ventas optimas")) {
        // Llamar al método para obtener las películas con ventas óptimas
        String[] peliculasVentasOptimas = LogicaCine.obtenerPeliculasConVentasOptimas();

        // Mostrar el resultado en el txtR
        StringBuilder reporteVentasOptimas = new StringBuilder();
        reporteVentasOptimas.append("Peliculas con Ventas Óptimas:\n\n");

        for (String peliculaVenta : peliculasVentasOptimas) {
            reporteVentasOptimas.append(peliculaVenta).append("\n");
        }

        txtR.setText(reporteVentasOptimas.toString());
    } else {
        // Lógica para otros tipos de reportes (puedes implementarlos según tus necesidades)
        txtR.setText("Otro tipo de reporte");
    }
    }//GEN-LAST:event_cmbReporteActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btbSalir;
    private javax.swing.JComboBox<String> cmbReporte;
    private javax.swing.JLabel lblReporte;
    private javax.swing.JScrollPane scpReporte;
    private javax.swing.JTextArea txtR;
    // End of variables declaration//GEN-END:variables
}
