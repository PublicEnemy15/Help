
package Cine;

import javax.swing.JOptionPane;

public class Mantenimiento2 extends javax.swing.JInternalFrame {
    public Mantenimiento2() {
        initComponents();
        inicializarPreciosEnCampos();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblAtentadoenelAire = new javax.swing.JLabel();
        lblElExorcistaCreyentes = new javax.swing.JLabel();
        lblSonidoDeLibertad = new javax.swing.JLabel();
        lblElCasoMonroy = new javax.swing.JLabel();
        lblSawXElJuegodelMiedo = new javax.swing.JLabel();
        btnAceptar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        txtP2 = new javax.swing.JTextField();
        txtP1 = new javax.swing.JTextField();
        txtP3 = new javax.swing.JTextField();
        txtP5 = new javax.swing.JTextField();
        txtP4 = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Configurar precios");

        lblAtentadoenelAire.setText("Atentado en el Aire               US $");

        lblElExorcistaCreyentes.setText("El Exorcista: Creyentes         US $");

        lblSonidoDeLibertad.setText("Sonido De Libertad               US $");

        lblElCasoMonroy.setText("El Caso Monroy                    US $");

        lblSawXElJuegodelMiedo.setText("Saw X: El Juego del Miedo   US $");

        btnAceptar.setText("Aceptar");
        btnAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarActionPerformed(evt);
            }
        });

        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblElCasoMonroy)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtP4, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(lblSawXElJuegodelMiedo, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addComponent(txtP5, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(lblSonidoDeLibertad)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtP3, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblElExorcistaCreyentes)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtP2, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblAtentadoenelAire)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(25, 25, 25))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnAceptar)
                .addGap(57, 57, 57)
                .addComponent(btnSalir)
                .addGap(108, 108, 108))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(229, Short.MAX_VALUE)
                    .addComponent(txtP1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(25, 25, 25)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblAtentadoenelAire)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblElExorcistaCreyentes)
                    .addComponent(txtP2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSonidoDeLibertad)
                    .addComponent(txtP3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblElCasoMonroy)
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblSawXElJuegodelMiedo)
                            .addComponent(txtP5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAceptar)
                            .addComponent(btnSalir)))
                    .addComponent(txtP4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(65, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(26, 26, 26)
                    .addComponent(txtP1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(257, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarActionPerformed
 actualizarPrecios();
     // Obtiene los valores ingresados por el usuario
    double precioP1 = Double.parseDouble(txtP1.getText());
    double precioP2 = Double.parseDouble(txtP2.getText());
    double precioP3 = Double.parseDouble(txtP3.getText());
    double precioP4 = Double.parseDouble(txtP4.getText());
    double precioP5 = Double.parseDouble(txtP5.getText());

    // Guarda los precios (puedes realizar la lógica que necesites aquí)

    // Muestra un mensaje indicando que los precios se han guardado
    JOptionPane.showMessageDialog(this, "Los precios se han guardado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnAceptarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
 dispose();
    }//GEN-LAST:event_btnSalirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAceptar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel lblAtentadoenelAire;
    private javax.swing.JLabel lblElCasoMonroy;
    private javax.swing.JLabel lblElExorcistaCreyentes;
    private javax.swing.JLabel lblSawXElJuegodelMiedo;
    private javax.swing.JLabel lblSonidoDeLibertad;
    private javax.swing.JTextField txtP1;
    private javax.swing.JTextField txtP2;
    private javax.swing.JTextField txtP3;
    private javax.swing.JTextField txtP4;
    private javax.swing.JTextField txtP5;
    // End of variables declaration//GEN-END:variables

private void actualizarPrecios() {
        double precio1 = Double.parseDouble(txtP1.getText());
        double precio2 = Double.parseDouble(txtP2.getText());
        double precio3 = Double.parseDouble(txtP3.getText());
        double precio4 = Double.parseDouble(txtP4.getText());
        double precio5 = Double.parseDouble(txtP5.getText());
        
        LogicaCine.PRECIOS_USD[1] = precio1;
        LogicaCine.PRECIOS_USD[2] = precio2;
        LogicaCine.PRECIOS_USD[3] = precio3;
        LogicaCine.PRECIOS_USD[4] = precio4;
        LogicaCine.PRECIOS_USD[5] = precio5;
    }
private void inicializarPreciosEnCampos() {
        // Muestra los precios en los campos de texto
        txtP1.setText(String.valueOf(LogicaCine.PRECIOS_USD[1]));
        txtP2.setText(String.valueOf(LogicaCine.PRECIOS_USD[2]));
        txtP3.setText(String.valueOf(LogicaCine.PRECIOS_USD[3]));
        txtP4.setText(String.valueOf(LogicaCine.PRECIOS_USD[4]));
        txtP5.setText(String.valueOf(LogicaCine.PRECIOS_USD[5]));
    }
}
