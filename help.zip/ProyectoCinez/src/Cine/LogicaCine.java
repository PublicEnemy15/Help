package Cine;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import javax.swing.JTextField;

public class LogicaCine {
    public static final double[][] PRECIOS_BASE = {
    // Precios base por película y formato
    // Ajusta estos valores según tus necesidades
    {0.0, 0.0, 0.0, 0.0, 0.0, 0.0}, // Película "Seleccionar"
    {0.0, 7.50, 8.00, 6.50, 9.00, 7.00}, // Película "Atentado en el Aire"
    {0.0, 8.00, 8.50, 7.00, 10.00, 8.00}, // Película "El Exorcista: Creyentes"
    // ... Agrega los demás valores según tus películas y formatos
};

    public static final String[] PELICULA = {
        "Seleccionar",
        "Atentado en el Aire",
        "El Exorcista: Creyentes",
        "Sonido De Libertad",
        "El Caso Monroy",
        "Saw X: El Juego del Miedo"
    };
     public static int[] entradasVendidasPorPelicula = new int[PELICULA.length];

    public static final String[] FORMATO = {
        "Seleccionar",
        "2D",
        "3D",
        "DBOX",
        "XD",
        "DOB"
    };

    public static final String[] FUNCION = {
        "Seleccionar",
        "2D",
        "3D",
        "DBOX",
        "XD",
        "DOB"
    };

    public static final String[][] GENEROS_POR_PELICULA = {
        {""},
        {"Thriller", "Acción"},
        {"Terror", "Sobrenatural"},
        {"Drama", "Musical"},
        {"Misterio", "Suspense"},
        {"Horror", "Gore"}
    };

    public static final String[][] DURACION_POR_PELICULA = {
        {""},
        {"1h 45m"},
        {"1h 30m"},
        {"1h 55m"},
        {"2h 10m"},
        {"1h 20m"}
    };

    public static final String[][] CLASIFICACION_POR_PELICULA = {
        {""},
        {"+18"},
        {"+18"},
        {"Apta para todo público"},
        {"+16"},
        {"+18"}
    };
    public static double convertirDolaresASoles(double precioUSD) {
        return precioUSD * DOLAR;
    }
    public static final double[] PRECIOS_POR_FORMATO = {
        0.0,    // Precio base
        1.0,    // Precio para formato 2D
        1.2,    // Precio para formato 3D
        1.5,    // Precio para formato DBOX
        1.8,    // Precio para formato XD
        2.0     // Precio para formato DOB
    };
    public static final double DOLAR = 3.50;
    public static final double[] PRECIOS_USD = {
        0.0,    // Precio base
        7.50,   // Precio para "Atentado en el Aire"
        8.00,   // Precio para "El Exorcista: Creyentes"
        6.50,   // Precio para "Sonido De Libertad"
        9.00,   // Precio para "El Caso Monroy"
        7.00    // Precio para "Saw X: El Juego del Miedo"
    };

public static void actualizarGeneroDuracionClasificacion(String pelicula, JTextField txtGenero, JTextField txtDuracion, JTextField txtClasificacion) {
        int indexPelicula = buscarPelicula(pelicula);
        if (indexPelicula >= 0) {
            txtGenero.setText(GENEROS_POR_PELICULA[indexPelicula][0]);
            txtDuracion.setText(DURACION_POR_PELICULA[indexPelicula][0]);
            txtClasificacion.setText(CLASIFICACION_POR_PELICULA[indexPelicula][0]);
        } else {
            txtGenero.setText("");
            txtDuracion.setText("");
            txtClasificacion.setText("");
        }
    }

    static int buscarPelicula(String pelicula) {
        for (int i = 0; i < PELICULA.length; i++) {
            if (PELICULA[i].equals(pelicula)) {
                return i;
            }
        }
        return -1;
    }

public static BigDecimal obtenerPrecioBase(String pelicula, String formato) {
    int indexPelicula = buscarPelicula(pelicula) - 1;
    int indexFormato = buscarFormato(formato) - 1;

    System.out.println("Index Pelicula: " + indexPelicula);
    System.out.println("Index Formato: " + indexFormato);

    if (indexPelicula >= 0 && indexFormato >= 0 && indexPelicula < PRECIOS_BASE.length && indexFormato < PRECIOS_BASE[0].length) {
        // Aquí deberías tener un array bidimensional con los precios base por película y formato
        BigDecimal precioBase = BigDecimal.valueOf(PRECIOS_BASE[indexPelicula][indexFormato]);
        return precioBase;
    }

    // En caso de no encontrar la película o formato, devolver un valor por defecto
    return BigDecimal.ZERO;
}

private static int buscarFormato(String formato) {
    for (int i = 0; i < FORMATO.length; i++) {
        if (FORMATO[i].equals(formato)) {
            return i;
        }
    }
    return -1;
}
    public static BigDecimal obtenerPrecioFormato(String formato) {
    int indexFormato = buscarFormato(formato);

    if (indexFormato >= 0) {
        // Aquí deberías tener un array con los precios por formato
        BigDecimal precioFormato = BigDecimal.valueOf(PRECIOS_POR_FORMATO[indexFormato]);
        return precioFormato;
    }

    // En caso de no encontrar el formato, devolver un valor por defecto
    return BigDecimal.ZERO;
}

public static double calcularPrecio(String formato, double precioBase, int cantidad, String pelicula) {
    double precioTotal = precioBase * cantidad;

    // Lógica para calcular el precio total según el formato y la cantidad
    // ...

    // Redondear el resultado a favor si es en soles
    if (formato.equalsIgnoreCase("soles")) {
        BigDecimal bd = new BigDecimal(precioTotal);
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        precioTotal = bd.doubleValue();
    }

    // Registra la venta
    registrarVenta(pelicula, precioTotal);

    return precioTotal;
}
public static double[] importeAcumuladoPorPelicula = new double[PELICULA.length];

    // ... (resto del código existente)

    public static void registrarVenta(String pelicula, double importeTotal) {
        int indexPelicula = buscarPelicula(pelicula);
        if (indexPelicula >= 0) {
            importeAcumuladoPorPelicula[indexPelicula] += importeTotal;
        }
    }
public static String[] obtenerPeliculasConVentasOptimas() {
    PeliculaVenta[] peliculasVentas = new PeliculaVenta[PELICULA.length - 1];

    for (int i = 1; i < PELICULA.length; i++) {
        peliculasVentas[i - 1] = new PeliculaVenta(PELICULA[i], importeAcumuladoPorPelicula[i]);
    }

    Arrays.sort(peliculasVentas, (a, b) -> Double.compare(b.getImporteAcumulado(), a.getImporteAcumulado()));

    String[] peliculasOrdenadas = new String[peliculasVentas.length];
    for (int i = 0; i < peliculasVentas.length; i++) {
        peliculasOrdenadas[i] = peliculasVentas[i].toString();
    }

    return peliculasOrdenadas;
}

    // Clase interna para almacenar información sobre las ventas de una película
    private static class PeliculaVenta {
        private String nombrePelicula;
        private double importeAcumulado;

        public PeliculaVenta(String nombrePelicula, double importeAcumulado) {
            this.nombrePelicula = nombrePelicula;
            this.importeAcumulado = importeAcumulado;
        }

        public String getNombrePelicula() {
            return nombrePelicula;
        }

        public double getImporteAcumulado() {
            return importeAcumulado;
        }

        @Override
        public String toString() {
            return nombrePelicula + ": Importe Acumulado $" + importeAcumulado;
        }
    }

}